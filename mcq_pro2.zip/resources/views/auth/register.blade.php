<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MCQ PRO - Create Account</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Essential CSS Files for Auth Pages (Multiple Loading Methods for cPanel Compatibility) -->
    <link rel="stylesheet" href="{{ asset('css/button-fixes.css') }}">
    <link rel="stylesheet" href="{{ url('css/button-fixes.css') }}">
    <link rel="stylesheet" href="/css/button-fixes.css">
    
    <link rel="stylesheet" href="{{ asset('css/auth-pages.css') }}">
    <link rel="stylesheet" href="{{ url('css/auth-pages.css') }}">
    <link rel="stylesheet" href="/css/auth-pages.css">
    
    <link rel="stylesheet" href="{{ asset('css/mobile-auth.css') }}">
    <link rel="stylesheet" href="{{ url('css/mobile-auth.css') }}">
    <link rel="stylesheet" href="/css/mobile-auth.css">
    
    <link rel="stylesheet" href="{{ asset('css/global-fixes.css') }}">
    <link rel="stylesheet" href="{{ url('css/global-fixes.css') }}">
    <link rel="stylesheet" href="/css/global-fixes.css">
    
    <!-- JavaScript Files for Auth Pages -->
    <script src="{{ asset('js/global-fixes.js') }}"></script>
    <script src="{{ url('js/global-fixes.js') }}"></script>
    <script src="/js/global-fixes.js"></script>
    
    <script src="{{ asset('js/auth-enhanced.js') }}"></script>
    <script src="{{ url('js/auth-enhanced.js') }}"></script>
    <script src="/js/auth-enhanced.js"></script>
    
    <style>
    /* Professional text colors for auth pages */
    body, p, span, div, h1, h2, h3, h4, h5, h6, li, label {
        color: #1f2937 !important;
    }
    
    .text-gray-900, .text-gray-800, .text-gray-700 {
        color: #1f2937 !important;
    }
    
    .text-gray-600 {
        color: #4b5563 !important;
    }
    
    .text-gray-500 {
        color: #6b7280 !important;
    }
    
    /* Form text colors */
    .form-control, .form-label, input, textarea {
        color: #1f2937 !important;
    }
    
    /* Exception for buttons */
    button, .btn, a.btn {
        color: inherit !important;
    }
    </style>
</head>
<body>
    <div class="mobile-auth-container">
        <!-- Status Bar -->
        <div class="status-bar">
            <div class="status-time">9:41</div>
            <div class="status-icons">
                <span>•••</span>
                <i class="fas fa-wifi"></i>
                <i class="fas fa-battery-three-quarters"></i>
            </div>
        </div>

        <!-- Page Title -->
        <div class="page-title">
            <h1>Let's Build your</h1>
            <div class="subtitle">
                <span class="brand-highlight">H</span><span style="color: #f59e0b;">care</span> Profile
            </div>
        </div>

        <!-- Illustration -->
        <div class="auth-illustration register-illustration">
            <div class="illustration-bg">
                <div class="illustration-character">
                    <div class="character-body">
                        <div class="character-head"></div>
                        <div class="character-torso"></div>
                        <div class="character-arms">
                            <div class="arm-left"></div>
                            <div class="arm-right"></div>
                        </div>
                        <div class="character-legs">
                            <div class="leg-left"></div>
                            <div class="leg-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Social Buttons -->
        <div class="social-buttons">
            <a href="{{ route('auth.google') }}" class="social-btn social-btn-google">
                <svg class="social-icon" viewBox="0 0 24 24">
                    <path fill="white" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="white" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="white" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="white" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continue with google
            </a>
            
            <a href="#" class="social-btn social-btn-facebook">
                <i class="fab fa-facebook-f social-icon"></i>
                Continue with facebook
            </a>
        </div>
        
        <!-- Alert Messages -->
        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ session('error') }}</span>
            </div>
        @endif
        
        @if($errors->any())
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>
                    @foreach($errors->all() as $error)
                        {{ $error }}@if(!$loop->last)<br>@endif
                    @endforeach
                </span>
            </div>
        @endif
        
        <!-- Registration Form -->
        <form method="POST" action="{{ route('register.submit') }}" class="auth-form" id="registerForm">
            @csrf
            
            <div class="form-row">
                <div class="form-group">
                    <input type="text" 
                           class="form-input" 
                           name="first_name" 
                           placeholder="First name" 
                           value="{{ old('first_name') }}" 
                           required
                           id="first_name">
                </div>
                <div class="form-group">
                    <input type="text" 
                           class="form-input" 
                           name="last_name" 
                           placeholder="Last name" 
                           value="{{ old('last_name') }}" 
                           required
                           id="last_name">
                </div>
            </div>
            
            <!-- Hidden field for combined name -->
            <input type="hidden" name="name" id="combined_name">
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" 
                           class="form-input" 
                           name="email" 
                           placeholder="Enter your e-mail address" 
                           value="{{ old('email') }}" 
                           required 
                           autocomplete="email">
                </div>
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" 
                           class="form-input" 
                           name="password" 
                           placeholder="Enter Password" 
                           required 
                           autocomplete="new-password"
                           id="password">
                </div>
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" 
                           class="form-input" 
                           name="password_confirmation" 
                           placeholder="Confirm password" 
                           required 
                           autocomplete="new-password"
                           id="password_confirmation">
                </div>
            </div>
            
            <div class="bottom-actions">
                <button type="button" class="btn btn-secondary">
                    Cancel
                </button>
                <button type="submit" class="btn btn-primary" id="registerBtn">
                    Create account
                </button>
            </div>
        </form>
        
        <!-- Auth Link -->
        <div class="auth-link">
            <a href="{{ route('login') }}">Already have an account? Sign in</a>
        </div>
    </div>
    
    <script src="{{ asset('js/auth-enhanced.js') }}"></script>
    <script>
        // Password toggle functionality
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const eye = document.getElementById(inputId + '-eye');
            
            if (input.type === 'password') {
                input.type = 'text';
                eye.classList.remove('fa-eye');
                eye.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                eye.classList.remove('fa-eye-slash');
                eye.classList.add('fa-eye');
            }
        }
        
        // Combine first and last name
        function updateCombinedName() {
            const firstName = document.getElementById('first_name').value.trim();
            const lastName = document.getElementById('last_name').value.trim();
            const combinedName = (firstName + ' ' + lastName).trim();
            document.getElementById('combined_name').value = combinedName;
        }
        
        document.getElementById('first_name').addEventListener('input', updateCombinedName);
        document.getElementById('last_name').addEventListener('input', updateCombinedName);
        
        // Form submission with loading state
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            updateCombinedName(); // Ensure name is combined before submit
            const btn = document.getElementById('registerBtn');
            btn.classList.add('btn-loading');
            btn.disabled = true;
        });
        
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(function() {
                    alert.remove();
                }, 300);
            });
        }, 5000);
    </script>
</body>
</html>
