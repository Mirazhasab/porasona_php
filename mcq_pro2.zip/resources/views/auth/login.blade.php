<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MCQ PRO - Sign In</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- CSS & JS Files (only include if present to avoid 404s on some servers) -->
    @php
        $cssFiles = [
            'css/asset-loader.css',
            'css/auth-pages.css',
            'css/mobile-auth.css',
            'css/force-light-theme.css',
        ];

        $jsFiles = [
            'js/asset-loader.js',
            'js/auth-enhanced.js',
        ];
    @endphp

    @foreach($cssFiles as $css)
        @if(file_exists(public_path($css)))
            <link rel="stylesheet" href="{{ asset($css) }}?v={{ filemtime(public_path($css)) }}">
        @endif
    @endforeach

    @foreach($jsFiles as $js)
        @if(file_exists(public_path($js)))
            <script src="{{ asset($js) }}?v={{ filemtime(public_path($js)) }}" defer></script>
        @endif
    @endforeach
    
    <style>
    /* Light theme colors for auth pages */
    body {
        background-color: #f8fafc !important;
        color: #1e293b !important;
    }
    
    .mobile-auth-container {
        background-color: #f8fafc !important;
    }
    
    .auth-form {
        background-color: #ffffff !important;
    }
    
    /* Text colors */
    body, p, span, div, h1, h2, h3, h4, h5, h6, li, label {
        color: #1e293b !important;
    }
    
    .text-gray-900, .text-gray-800, .text-gray-700 {
        color: #1e293b !important;
    }
    
    .text-gray-600 {
        color: #475569 !important;
    }
    
    .text-gray-500 {
        color: #64748b !important;
    }
    
    /* Form colors */
    .form-control, .form-label, input, textarea {
        color: #1e293b !important;
        background-color: #ffffff !important;
        border-color: #cbd5e1 !important;
    }
    
    /* Button colors */
    .btn-primary {
        background-color: #3b82f6 !important;
        border-color: #3b82f6 !important;
        color: #ffffff !important;
    }
    
    .btn-primary:hover {
        background-color: #2563eb !important;
        border-color: #2563eb !important;
    }
    </style>
</head>
<body>
    <div class="mobile-auth-container">
        <!-- Brand Header -->
        <div class="brand-header">
            <div class="brand-logo">
                <span class="h-text">MCQ</span><span class="care-text">Pro</span>
            </div>
        </div>

        <!-- Illustration -->
        <div class="auth-illustration">
            <div class="illustration-bg">
                <div class="illustration-character">
                    <div class="character-body">
                        <div class="character-head"></div>
                        <div class="character-torso"></div>
                        <div class="character-arms">
                            <div class="arm-left"></div>
                            <div class="arm-right"></div>
                        </div>
                        <div class="character-legs">
                            <div class="leg-left"></div>
                            <div class="leg-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Alert Messages -->
        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ session('error') }}</span>
            </div>
        @endif
        
        @if($errors->any())
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>
                    @foreach($errors->all() as $error)
                        {{ $error }}@if(!$loop->last)<br>@endif
                    @endforeach
                </span>
            </div>
        @endif
        
        <!-- Login Form -->
        <form method="POST" action="{{ route('login.submit') }}" class="auth-form" id="loginForm">
            @csrf
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" 
                           class="form-input" 
                           name="email" 
                           placeholder="Enter your e-mail address" 
                           value="{{ old('email') }}" 
                           required 
                           autocomplete="email">
                </div>
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" 
                           class="form-input" 
                           name="password" 
                           placeholder="Password" 
                           required 
                           autocomplete="current-password"
                           id="password">
                </div>
            </div>
            
            <div class="forgot-password" style="display: flex; justify-content: space-between; align-items: center;">
                <a href="#" class="forgot-link">Forgot your Password?</a>
                <a href="/auth/google" style="color: #4285f4; text-decoration: none; font-size: 0.85rem; font-weight: 500;">
                    <i class="fab fa-google" style="margin-right: 4px;"></i>Continue with Google
                </a>
            </div>
            
            <button type="submit" class="btn btn-primary" id="loginBtn">
                Sign in
            </button>
        </form>
        
        <!-- Google Login Button -->
        <div style="margin: 20px 0; text-align: center;">
            <div style="margin: 15px 0; color: #666; font-size: 14px;">or</div>
            <a href="/auth/google" style="display: block; background: #4285f4; color: white; padding: 12px 20px; border-radius: 8px; text-decoration: none; font-weight: 500;">
                <i class="fab fa-google" style="margin-right: 8px;"></i>
                Continue with Google
            </a>
        </div>
        
        <!-- Auth Link -->
        <div class="auth-link">
            <a href="{{ route('register') }}">Don't have account? Create new</a>
        </div>
    </div>
    

    <script>
        // Password toggle functionality
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const eye = document.getElementById(inputId + '-eye');
            
            if (input.type === 'password') {
                input.type = 'text';
                eye.classList.remove('fa-eye');
                eye.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                eye.classList.remove('fa-eye-slash');
                eye.classList.add('fa-eye');
            }
        }
        
        // Form submission with loading state
        document.getElementById('loginForm').addEventListener('submit', function() {
            const btn = document.getElementById('loginBtn');
            btn.classList.add('btn-loading');
            btn.disabled = true;
        });
        
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(function(alert) {
                alert.style.opacity = '0';
                alert.style.transform = 'translateY(-10px)';
                setTimeout(function() {
                    alert.remove();
                }, 300);
            });
        }, 5000);
    </script>
</body>
</html>
