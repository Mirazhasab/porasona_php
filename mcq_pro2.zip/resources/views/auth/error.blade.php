<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MCQ PRO - Authentication Error</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .error-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
            padding: 3rem;
            max-width: 500px;
            width: 100%;
            text-align: center;
        }
        .error-icon {
            font-size: 4rem;
            color: #dc3545;
            margin-bottom: 1rem;
            animation: shake 0.5s ease-in-out;
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
        }
        .error-title {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            margin-bottom: 1rem;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            border-radius: 10px;
            padding: 1rem;
            margin: 1.5rem 0;
        }
        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 2rem;
        }
        .btn-custom {
            padding: 12px 25px;
            border-radius: 50px;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.3s ease;
            border: none;
        }
        .btn-primary-custom {
            background: linear-gradient(45deg, #667eea, #764ba2);
            color: white;
        }
        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.3);
            color: white;
            text-decoration: none;
        }
        .btn-outline-custom {
            background: transparent;
            color: #666;
            border: 2px solid #ddd;
        }
        .btn-outline-custom:hover {
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
        }
        .troubleshooting {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 1.5rem;
            margin-top: 2rem;
            text-align: left;
        }
        .troubleshooting h6 {
            color: #333;
            margin-bottom: 1rem;
        }
        .troubleshooting ul {
            margin: 0;
            padding-left: 1.5rem;
        }
        .troubleshooting li {
            color: #666;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="error-card">
        <div class="error-icon">
            <i class="fas fa-exclamation-triangle"></i>
        </div>
        
        <h1 class="error-title">Authentication Failed</h1>
        <p class="text-muted">We encountered an issue while trying to log you in</p>
        
        @if(session('error'))
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                {{ session('error') }}
            </div>
        @else
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                An unexpected error occurred during the authentication process.
            </div>
        @endif
        
        <div class="action-buttons">
            <a href="{{ route('login') }}" class="btn-custom btn-primary-custom">
                <i class="fas fa-redo"></i> Try Again
            </a>
            <a href="/" class="btn-custom btn-outline-custom">
                <i class="fas fa-home"></i> Go Home
            </a>
        </div>
        
        <div class="troubleshooting">
            <h6><i class="fas fa-tools"></i> Troubleshooting Tips:</h6>
            <ul>
                <li>Make sure you have a stable internet connection</li>
                <li>Clear your browser cache and cookies</li>
                <li>Try using a different browser or incognito mode</li>
                <li>Ensure pop-ups are not blocked for this site</li>
                <li>Check if you have multiple Google accounts and select the correct one</li>
            </ul>
        </div>
        
        <div class="mt-4">
            <small class="text-muted">
                <i class="fas fa-question-circle"></i>
                If the problem persists, please contact support
            </small>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
