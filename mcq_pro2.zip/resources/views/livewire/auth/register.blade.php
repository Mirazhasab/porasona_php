<div>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Essential CSS Files for Livewire Auth (Multiple Loading Methods for cPanel Compatibility) -->
    <link rel="stylesheet" href="{{ asset('css/button-fixes.css') }}">
    <link rel="stylesheet" href="{{ url('css/button-fixes.css') }}">
    <link rel="stylesheet" href="/css/button-fixes.css">
    
    <link rel="stylesheet" href="{{ asset('css/mobile-auth.css') }}">
    <link rel="stylesheet" href="{{ url('css/mobile-auth.css') }}">
    <link rel="stylesheet" href="/css/mobile-auth.css">
    
    <link rel="stylesheet" href="{{ asset('css/global-fixes.css') }}">
    <link rel="stylesheet" href="{{ url('css/global-fixes.css') }}">
    <link rel="stylesheet" href="/css/global-fixes.css">
    
    <!-- JavaScript Files for Livewire Auth -->
    <script src="{{ asset('js/global-fixes.js') }}"></script>
    <script src="{{ url('js/global-fixes.js') }}"></script>
    <script src="/js/global-fixes.js"></script>
    
    <script src="{{ asset('js/auth-enhanced.js') }}"></script>
    <script src="{{ url('js/auth-enhanced.js') }}"></script>
    <script src="/js/auth-enhanced.js"></script>
    
    <style>
        /* Override body styles for Livewire component */
        body {
            background: linear-gradient(135deg, #e8d5ff 0%, #c4a3ff 50%, #a78bfa 100%) !important;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            position: relative;
            overflow-x: hidden;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
    </style>

        <!-- Page Title -->
        <div class="page-title">
            <h1>Let's Build your</h1>
            <div class="subtitle">
                <span class="brand-highlight">MCQ</span><span style="color: #f59e0b;">Pro</span> Profile
            </div>
        </div>

        <!-- Illustration -->
        <div class="auth-illustration register-illustration">
            <div class="illustration-bg">
                <div class="mcq-book">
                    <div class="book-cover">
                        <div class="book-title">MCQ</div>
                        <div class="book-subtitle">Pro</div>
                        <div class="book-decoration">
                            <div class="question-mark">?</div>
                            <div class="answer-options">
                                <div class="option option-a">A</div>
                                <div class="option option-b">B</div>
                                <div class="option option-c">C</div>
                                <div class="option option-d">D</div>
                            </div>
                        </div>
                    </div>
                    <div class="book-spine"></div>
                    <div class="book-shadow"></div>
                </div>
            </div>
        </div>

        <!-- Social Buttons -->
        <div class="social-buttons">
            <a href="{{ route('auth.google') }}" class="social-btn social-btn-google">
                <svg class="social-icon" viewBox="0 0 24 24">
                    <path fill="white" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="white" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="white" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="white" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continue with google
            </a>
            
            <a href="#" class="social-btn social-btn-facebook">
                <i class="fab fa-facebook-f social-icon"></i>
                Continue with facebook
            </a>
        </div>
        
        <!-- Alert Messages -->
        @if($error)
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ $error }}</span>
            </div>
        @endif
        
        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif
        
        <!-- Registration Form -->
        <form wire:submit.prevent="register" class="auth-form">
            <div class="form-group">
                <input type="text" 
                       class="form-input" 
                       wire:model="name"
                       placeholder="Full name" 
                       required>
                @error('name')
                    <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" 
                           class="form-input" 
                           wire:model="email"
                           placeholder="Enter your e-mail address" 
                           required 
                           autocomplete="email">
                </div>
                @error('email')
                    <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" 
                           class="form-input" 
                           wire:model="password"
                           placeholder="Enter Password" 
                           required 
                           autocomplete="new-password">
                </div>
                @error('password')
                    <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" 
                           class="form-input" 
                           wire:model="password_confirmation"
                           placeholder="Confirm password" 
                           required 
                           autocomplete="new-password">
                </div>
            </div>
            
            <div class="bottom-actions">
                <button type="button" class="btn btn-secondary">
                    Cancel
                </button>
                <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                    <span wire:loading.remove wire:target="register">Create account</span>
                    <span wire:loading wire:target="register">Creating...</span>
                </button>
            </div>
        </form>
        
        <!-- Auth Link -->
        <div class="auth-link">
            <a href="{{ route('login') }}" wire:navigate>Already have an account? Sign in</a>
        </div>
    </div>
</div>
