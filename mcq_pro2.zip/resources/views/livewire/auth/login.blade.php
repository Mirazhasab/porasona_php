<div>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Essential CSS Files for Livewire Auth (Multiple Loading Methods for cPanel Compatibility) -->
    <link rel="stylesheet" href="{{ asset('css/button-fixes.css') }}">
    <link rel="stylesheet" href="{{ url('css/button-fixes.css') }}">
    <link rel="stylesheet" href="/css/button-fixes.css">
    
    <link rel="stylesheet" href="{{ asset('css/mobile-auth.css') }}">
    <link rel="stylesheet" href="{{ url('css/mobile-auth.css') }}">
    <link rel="stylesheet" href="/css/mobile-auth.css">
    
    <link rel="stylesheet" href="{{ asset('css/global-fixes.css') }}">
    <link rel="stylesheet" href="{{ url('css/global-fixes.css') }}">
    <link rel="stylesheet" href="/css/global-fixes.css">
    
    <!-- JavaScript Files for Livewire Auth -->
    <script src="{{ asset('js/global-fixes.js') }}"></script>
    <script src="{{ url('js/global-fixes.js') }}"></script>
    <script src="/js/global-fixes.js"></script>
    
    <script src="{{ asset('js/auth-enhanced.js') }}"></script>
    <script src="{{ url('js/auth-enhanced.js') }}"></script>
    <script src="/js/auth-enhanced.js"></script>
    
    <style>
        /* Override body styles for Livewire component */
        body {
            background: linear-gradient(135deg, #e8d5ff 0%, #c4a3ff 50%, #a78bfa 100%) !important;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            position: relative;
            overflow-x: hidden;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }
    </style>

    <div class="mobile-auth-container">
        <!-- Status Bar -->
      

        <!-- Brand Header -->
        <div class="brand-header">
            <div class="brand-logo">
                <span class="h-text">MCQ</span><span class="care-text">Pro</span>
            </div>
        </div>

        <!-- Illustration -->
        <div class="auth-illustration">
            <div class="illustration-bg">
                <div class="mcq-book">
                    <div class="book-cover">
                        <div class="book-title">MCQ</div>
                        <div class="book-subtitle">Questions</div>
                        <div class="book-decoration">
                            <div class="question-mark">?</div>
                            <div class="answer-options">
                                <div class="option option-a">A</div>
                                <div class="option option-b">B</div>
                                <div class="option option-c">C</div>
                                <div class="option option-d">D</div>
                            </div>
                        </div>
                    </div>
                    <div class="book-spine"></div>
                    <div class="book-shadow"></div>
                </div>
            </div>
        </div>
        
        <!-- Alert Messages -->
        @if($error)
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <span>{{ $error }}</span>
            </div>
        @endif
        
        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i>
                <span>{{ session('success') }}</span>
            </div>
        @endif
        
        <!-- Login Form -->
        <form wire:submit.prevent="login" class="auth-form">
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-envelope input-icon"></i>
                    <input type="email" 
                           class="form-input" 
                           wire:model="email"
                           placeholder="Enter your e-mail address" 
                           required 
                           autocomplete="email">
                </div>
                @error('email')
                    <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="form-group">
                <div class="input-wrapper">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" 
                           class="form-input" 
                           wire:model="password"
                           placeholder="Password" 
                           required 
                           autocomplete="current-password">
                </div>
                @error('password')
                    <div class="text-red-500 text-sm mt-1">{{ $message }}</div>
                @enderror
            </div>
            
            <div class="forgot-password" style="display: flex; justify-content: space-between; align-items: center;">
                <a href="#" class="forgot-link">Forgot Password?</a>
                <a href="/auth/google" style="color: #4285f4; text-decoration: none; font-size: 0.85rem; font-weight: 500;">
                    <i class="fab fa-google" style="margin-right: 4px;"></i>Continue with Google
                </a>
            </div>
            
            <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
                <span wire:loading.remove wire:target="login">Sign in</span>
                <span wire:loading wire:target="login">Signing in...</span>
            </button>
        </form>
        
        <!-- Auth Link -->
        <div class="auth-link">
            <a href="{{ route('register') }}" wire:navigate>Don't have account? Create new</a>
        </div>
    </div>
</div>
