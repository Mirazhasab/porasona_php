@extends('layouts.mcq')

@section('title', 'Read MCQ Content - ' . $mcqSet->title)
@section('page-title', $mcqSet->title)
@section('page-subtitle', 'Study MCQ Content')

@section('content')
<!-- Container -->
<div class="mcq-theme max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
    <!-- Back Button -->
    <div class="mt-6 mb-4 animate-fade-in">
        <a href="{{ route('mcq.read') }}" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-xl hover:from-purple-600 hover:to-pink-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl" aria-label="Back to MCQ Library">
            <i data-lucide="arrow-left" class="w-5 h-5 mr-2" aria-hidden="true"></i>
            <span class="font-medium">Back to MCQ Library</span>
        </a>
    </div>

    <!-- MCQ Set Header -->
    <section class="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 rounded-3xl border-2 border-indigo-200 shadow-xl mb-8 overflow-hidden animate-slide-up">
        <div class="p-6 lg:flex lg:items-center lg:justify-between">
            <div class="lg:flex-1">
                <h1 class="text-3xl lg:text-4xl font-extrabold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent leading-tight">{{ $mcqSet->title }}</h1>
                <div class="mt-2 flex flex-col sm:flex-row sm:items-center sm:space-x-4">
                    @if($mcqSet->category)
                        <span class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-emerald-400 to-teal-500 text-white text-sm rounded-full shadow-md animate-pulse" role="status">
                            <i data-lucide="tag" class="w-4 h-4 mr-1" aria-hidden="true"></i>
                            {{ ucfirst($mcqSet->category) }}
                        </span>
                    @endif
                    @if($mcqSet->exam_name)
                        <p class="text-sm text-gray-600 mt-2 sm:mt-0">{{ $mcqSet->exam_name }}</p>
                    @endif
                </div>
            </div>

            <div class="mt-4 lg:mt-0 lg:ml-6 flex items-center gap-4">
                <div class="w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg animate-bounce">
                    <i data-lucide="book-open" class="w-10 h-10 text-white" aria-hidden="true"></i>
                </div>
                <div class="hidden sm:block">
                    <dl class="grid grid-cols-2 gap-2 text-sm text-gray-600">
                        <div>
                            <dt class="font-medium text-gray-700">Questions</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $stats['totalQuestions'] }}</dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-700">Total Marks</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $stats['totalMarks'] }}</dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-700">Duration</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $stats['duration'] }} min</dd>
                        </div>
                        <div>
                            <dt class="font-medium text-gray-700">Difficulty</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $stats['difficulty'] }}</dd>
                        </div>
                    </dl>
                </div>
            </div>
        </div>

        @if($stats['hasAttempted'])
            <div class="px-6 pb-6">
                <div class="mt-3 p-4 bg-gradient-to-r from-cyan-50 to-blue-50 border-2 border-cyan-200 rounded-xl text-sm text-cyan-800 shadow-md animate-pulse">
                    <i data-lucide="info" class="w-4 h-4 inline mr-2" aria-hidden="true"></i>
                    You previously attempted this MCQ set on <strong>{{ $stats['lastAttempted']->format('M d, Y \a\t g:i A') }}</strong>.
                </div>
            </div>
        @endif
    </section>

    <!-- Questions Content -->
    <article class="bg-white rounded-2xl border border-gray-200 shadow-sm">
        <header class="p-6 border-b border-gray-100 flex items-center justify-between">
            <h2 class="text-lg font-semibold text-gray-900">Questions & Answers</h2>
            <div class="flex items-center gap-3">
                @if(auth()->user()->access && auth()->user()->access->exams)
                    <a href="{{ route('exams.show', $mcqSet->id) }}" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl hover:from-emerald-600 hover:to-teal-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl">
                        <i data-lucide="play" class="w-4 h-4 mr-2" aria-hidden="true"></i>
                        <span class="text-sm font-medium">Take Exam</span>
                    </a>
                @endif
                <button id="toggleAllBtn" onclick="toggleAllAnswers()" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-xl hover:from-indigo-600 hover:to-purple-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl" aria-pressed="false">
                    <i data-lucide="eye" class="w-4 h-4 mr-2" aria-hidden="true"></i>
                    <span id="toggleText">Show All Answers</span>
                </button>
            </div>
        </header>

        <div class="p-6">
            @if($mcqSet->questions->count() > 0)
                <div class="space-y-6">
                    @foreach($mcqSet->questions as $index => $question)
                        <section class="question-card bg-gradient-to-br from-white to-blue-50 border-2 border-blue-200 rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:scale-[1.02] animate-fade-in-up" style="animation-delay: {{ ($index * 0.1) }}s" aria-labelledby="question-{{ $question->id }}">
                            <div class="flex items-start gap-4">
                                <div class="flex-shrink-0">
                                    <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 text-white rounded-2xl flex items-center justify-center font-bold text-lg shadow-lg animate-pulse">{{ $index + 1 }}</div>
                                </div>
                                <div class="flex-1">
                                    <h3 id="question-{{ $question->id }}" class="text-lg lg:text-xl font-bold text-gray-800">{{ $question->question }}</h3>
                                    <div class="mt-3 inline-flex items-center bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                                        <i data-lucide="award" class="w-4 h-4 inline mr-1" aria-hidden="true"></i>
                                        <span>{{ $question->marks ?? 1 }} {{ ($question->marks ?? 1) == 1 ? 'Mark' : 'Marks' }}</span>
                                    </div>

                                    <!-- Options -->
                                    <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                                        @for($i = 1; $i <= 4; $i++)
                                            @php
                                                $optionText = $question->{'ans_' . $i};
                                                $isCorrect = $question->correct_ans == $i;
                                                $userSelected = isset($userAnswers[$question->id]) && $userAnswers[$question->id]->selected_answer == $i;
                                            @endphp
                                            @if($optionText)
                                                <div class="option-item p-4 rounded-2xl border-2 transition-all duration-300 transform hover:scale-105 hover:shadow-xl option-block
                                                    {{ $isCorrect ? 'bg-gradient-to-br from-green-100 to-emerald-100 border-green-300 shadow-lg is-correct' : 'bg-gradient-to-br from-gray-50 to-white border-gray-200' }}
                                                    {{ $userSelected && !$isCorrect ? 'bg-gradient-to-br from-red-100 to-pink-100 border-red-300 is-selected' : '' }}">
                                                    <div class="flex items-start gap-3">
                                                        <div class="flex-shrink-0">
                                                            <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-sm font-bold shadow-md option-badge
                                                                {{ $isCorrect ? 'bg-gradient-to-br from-green-500 to-emerald-600 text-white animate-pulse badge-correct' : 'bg-gradient-to-br from-pink-400 to-red-500 text-white badge-default' }}
                                                                {{ $userSelected && !$isCorrect ? 'bg-gradient-to-br from-red-500 to-pink-600 text-white badge-selected' : '' }}">
                                                                {{ chr(64 + $i) }}
                                                            </div>
                                                        </div>
                                                        <div class="flex-1 text-gray-800 font-medium">{{ $optionText }}</div>
                                                        <div class="flex-shrink-0">
                                                            @if($isCorrect)
                                                                <i data-lucide="check-circle" class="w-6 h-6 text-green-600 animate-bounce" aria-hidden="true"></i>
                                                            @endif
                                                            @if($userSelected && !$isCorrect)
                                                                <i data-lucide="x-circle" class="w-6 h-6 text-red-600 animate-pulse" aria-hidden="true"></i>
                                                            @endif
                                                        </div>
                                                    </div>
                                                </div>
                                            @endif
                                        @endfor
                                    </div>

                                    <!-- Answer Section (Initially Hidden) -->
                                    <div class="answer-section hidden mt-6 border-t-2 border-gradient-to-r from-indigo-200 to-purple-200 pt-6 animate-fade-in" aria-hidden="true">
                                        <div class="flex items-center gap-4 p-4 bg-gradient-to-r from-yellow-100 to-orange-100 rounded-2xl border-2 border-yellow-300">
                                            <i data-lucide="lightbulb" class="w-6 h-6 text-yellow-600 animate-pulse" aria-hidden="true"></i>
                                            <div>
                                                <p class="text-lg font-bold text-gray-800">Correct Answer</p>
                                                <p class="text-lg font-bold bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-2 rounded-xl shadow-lg mt-2 inline-block">{{ chr(64 + $question->correct_ans) }}. {{ $question->{'ans_' . $question->correct_ans} }}</p>
                                            </div>
                                        </div>
                                        @if($question->notes)
                                            <div class="mt-4 p-6 bg-gradient-to-br from-blue-50 to-indigo-100 border-2 border-blue-300 rounded-2xl shadow-lg text-blue-800">
                                                <strong>Explanation:</strong>
                                                <div class="mt-2 text-lg font-medium text-blue-800">💡 {{ $question->notes }}</div>
                                            </div>
                                        @endif
                                    </div>

                                    <!-- Individual Show Answer Button -->
                                    <div class="mt-4">
                                        <button onclick="toggleAnswer({{ $index }})" class="inline-flex items-center px-6 py-3 bg-gradient-to-r from-teal-500 to-cyan-600 text-white rounded-xl hover:from-teal-600 hover:to-cyan-700 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-medium" aria-expanded="false">
                                            <i data-lucide="eye" class="w-4 h-4 inline mr-2" aria-hidden="true"></i>
                                            <span class="toggle-text">Show Answer</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </section>
                    @endforeach
                </div>
            @else
                <div class="text-center py-16 animate-fade-in">
                    <div class="w-32 h-32 bg-gradient-to-br from-gray-200 to-gray-300 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
                        <i data-lucide="help-circle" class="w-16 h-16 text-gray-500"></i>
                    </div>
                    <h3 class="text-2xl font-bold bg-gradient-to-r from-gray-600 to-gray-800 bg-clip-text text-transparent mb-3">No Questions Available</h3>
                    <p class="text-gray-600 text-lg">This MCQ set doesn't have any questions yet.</p>
                </div>
            @endif
        </div>
    </article>
</div>
@endsection

@push('scripts')
<script>
let allAnswersVisible = false;

function toggleAllAnswers() {
    const answerSections = document.querySelectorAll('.answer-section');
    const toggleText = document.getElementById('toggleText');
    const toggleButtons = document.querySelectorAll('.toggle-text');
    
    allAnswersVisible = !allAnswersVisible;
    
    answerSections.forEach(section => {
        if (allAnswersVisible) {
            section.classList.remove('hidden');
        } else {
            section.classList.add('hidden');
        }
    });
    
    toggleButtons.forEach(button => {
        button.textContent = allAnswersVisible ? 'Hide Answer' : 'Show Answer';
    });
    
    toggleText.textContent = allAnswersVisible ? 'Hide All Answers' : 'Show All Answers';
}

function toggleAnswer(index) {
    const answerSection = document.querySelectorAll('.answer-section')[index];
    const toggleButton = document.querySelectorAll('.toggle-text')[index];
    
    if (answerSection.classList.contains('hidden')) {
        answerSection.classList.remove('hidden');
        toggleButton.textContent = 'Hide Answer';
    } else {
        answerSection.classList.add('hidden');
        toggleButton.textContent = 'Show Answer';
    }
}
</script>
@endpush

@push('styles')
<style>
    @keyframes fade-in {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes slide-up {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @keyframes fade-in-up {
        from { opacity: 0; transform: translateY(40px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .animate-fade-in {
        animation: fade-in 0.6s ease-out;
    }
    
    .animate-slide-up {
        animation: slide-up 0.8s ease-out;
    }
    
    .animate-fade-in-up {
        animation: fade-in-up 0.7s ease-out;
        animation-fill-mode: both;
    }
    
    .question-card {
        transition: all 0.5s ease;
    }
    
    .option-item {
        transition: all 0.3s ease;
    }
    /* Enhanced colorful animations */
    @keyframes gentle-pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.05); }
    }
    
    @keyframes rainbow-border {
        0% { border-color: #3b82f6; }
        25% { border-color: #10b981; }
        50% { border-color: #f59e0b; }
        75% { border-color: #ef4444; }
        100% { border-color: #8b5cf6; }
    }
    
    .animate-rainbow {
        animation: rainbow-border 3s ease-in-out infinite;
    }

    /* Print-friendly styles */
    @media print {
        /* Expand to full width and remove shadows/borders */
        .mcq-theme { max-width: 100% !important; margin: 0 !important; padding: 8px !important; }
        .mcq-theme .rounded-2xl, .mcq-theme .rounded-lg, .mcq-theme .rounded-full { border-radius: 0 !important; }
        .mcq-theme * { color: #000 !important; background: transparent !important; box-shadow: none !important; }
        .mcq-theme .border { border: 0 !important; }

        /* Show all answers in print */
        .mcq-theme .answer-section { display: block !important; visibility: visible !important; }

        /* Hide interactive controls (buttons) when printing, keep links visible */
        .mcq-theme button, .mcq-theme [aria-pressed], .mcq-theme .toggle-text { display: none !important; }

        /* Make option items print-friendly */
        .mcq-theme .option-item { page-break-inside: avoid; break-inside: avoid; }

        /* Ensure explanations are readable */
        .mcq-theme .bg-blue-50, .mcq-theme .bg-blue-100 { background: transparent !important; color: #111827 !important; }

        /* Remove icons from print to reduce ink usage */
        .mcq-theme i[data-lucide], .mcq-theme svg { display: none !important; }
    }
    /* Tight spacing overrides: limit margins/padding to ~2px for compact layout */
    .mcq-theme .p-6 { padding: 2px !important; }
    .mcq-theme .p-3 { padding: 2px !important; }
    .mcq-theme .px-3, .mcq-theme .px-4, .mcq-theme .px-6 { padding-left: 2px !important; padding-right: 2px !important; }
    .mcq-theme .py-2, .mcq-theme .py-4, .mcq-theme .py-6 { padding-top: 2px !important; padding-bottom: 2px !important; }
    .mcq-theme .pt-4, .mcq-theme .pt-3, .mcq-theme .pt-6 { padding-top: 2px !important; }
    .mcq-theme .pb-6, .mcq-theme .pb-4 { padding-bottom: 2px !important; }

    .mcq-theme .mt-6, .mcq-theme .mt-4, .mcq-theme .mt-3, .mcq-theme .mt-2 { margin-top: 2px !important; }
    .mcq-theme .mb-6, .mcq-theme .mb-4, .mcq-theme .mb-3, .mcq-theme .mb-2 { margin-bottom: 2px !important; }
    .mcq-theme .ml-6, .mcq-theme .mr-6, .mcq-theme .ml-4, .mcq-theme .mr-4 { margin-left: 2px !important; margin-right: 2px !important; }

    .mcq-theme .space-y-6 > * + * { margin-top: 2px !important; }
    .mcq-theme .gap-4, .mcq-theme .gap-3 { gap: 2px !important; }

    /* Reduce vertical spacing on headings and text blocks */
    .mcq-theme h1, .mcq-theme h2, .mcq-theme h3, .mcq-theme p { margin-top: 2px !important; margin-bottom: 2px !important; }
</style>
@endpush
