<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Check if sessions table exists, if not create it
        if (!Schema::hasTable('sessions')) {
            Schema::create('sessions', function (Blueprint $table) {
                $table->string('id')->primary();
                $table->foreignId('user_id')->nullable()->index();
                $table->string('ip_address', 45)->nullable();
                $table->text('user_agent')->nullable();
                $table->longText('payload');
                $table->integer('last_activity')->index();
                
                // Additional columns for session management
                $table->string('device_fingerprint')->nullable();
                $table->timestamp('login_at')->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        } else {
            // Modify existing sessions table to add our custom columns
            Schema::table('sessions', function (Blueprint $table) {
                // Check if columns don't exist before adding them
                if (!Schema::hasColumn('sessions', 'device_fingerprint')) {
                    $table->string('device_fingerprint')->nullable()->after('last_activity');
                }
                if (!Schema::hasColumn('sessions', 'login_at')) {
                    $table->timestamp('login_at')->nullable()->after('device_fingerprint');
                }
                if (!Schema::hasColumn('sessions', 'is_active')) {
                    $table->boolean('is_active')->default(true)->after('login_at');
                }
                if (!Schema::hasColumn('sessions', 'created_at')) {
                    $table->timestamps();
                }
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Only drop the columns we added, not the entire table
        if (Schema::hasTable('sessions')) {
            Schema::table('sessions', function (Blueprint $table) {
                if (Schema::hasColumn('sessions', 'device_fingerprint')) {
                    $table->dropColumn('device_fingerprint');
                }
                if (Schema::hasColumn('sessions', 'login_at')) {
                    $table->dropColumn('login_at');
                }
                if (Schema::hasColumn('sessions', 'is_active')) {
                    $table->dropColumn('is_active');
                }
                // Don't drop created_at/updated_at as they might be used elsewhere
            });
        }
    }
};
