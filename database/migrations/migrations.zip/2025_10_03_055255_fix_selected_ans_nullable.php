<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // For SQLite, we need to recreate the table to modify column constraints
        // First, let's make selected_ans nullable by updating the constraint
        
        // Create a temporary table with the correct structure
        Schema::create('mcq_answers_temp', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('mcq_set_id')->constrained()->cascadeOnDelete();
            $table->foreignId('question_id')->constrained('mcq_questions')->cascadeOnDelete();
            $table->string('selected_ans')->nullable()->comment('User selected answer (1-4)');
            $table->boolean('is_correct')->default(false)->comment('Auto-calculated: 1=correct, 0=wrong');
            $table->timestamps();
            $table->string('selected_answer')->nullable();
            $table->integer('marks_obtained')->default(0);
            $table->integer('time_taken')->default(0);
            
            $table->index('user_id');
            $table->index('mcq_set_id');
            $table->index('question_id');
        });
        
        // Copy data from old table to new table
        DB::statement('INSERT INTO mcq_answers_temp SELECT * FROM mcq_answers');
        
        // Drop old table and rename new table
        Schema::drop('mcq_answers');
        Schema::rename('mcq_answers_temp', 'mcq_answers');
        
        // Re-add the unique constraint
        Schema::table('mcq_answers', function (Blueprint $table) {
            $table->unique(['user_id', 'question_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // This migration is not easily reversible due to SQLite limitations
        // The down method would require recreating the original structure
    }
};
