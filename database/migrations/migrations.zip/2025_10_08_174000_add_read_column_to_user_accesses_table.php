<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_accesses', function (Blueprint $table) {
            $table->boolean('read_access')->default(false)->after('mcq_management');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_accesses', function (Blueprint $table) {
            $table->dropColumn('read_access');
        });
    }
};
