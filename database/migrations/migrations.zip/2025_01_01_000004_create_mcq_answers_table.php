<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mcq_answers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('mcq_set_id')->constrained()->cascadeOnDelete();
            $table->foreignId('question_id')->constrained('mcq_questions')->cascadeOnDelete();
            $table->enum('selected_ans', ['1', '2', '3', '4'])->comment('User selected answer (1-4)');
            $table->boolean('is_correct')->default(false)->comment('Auto-calculated: 1=correct, 0=wrong');
            $table->timestamps();
            
            $table->index('user_id');
            $table->index('mcq_set_id');
            $table->index('question_id');
            $table->unique(['user_id', 'question_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mcq_answers');
    }
};
