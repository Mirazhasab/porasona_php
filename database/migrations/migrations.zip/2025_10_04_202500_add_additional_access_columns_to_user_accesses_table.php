<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_accesses', function (Blueprint $table) {
            $table->boolean('practice')->default(false)->after('post');
            $table->boolean('exams')->default(false)->after('practice');
            $table->boolean('results')->default(false)->after('exams');
            $table->boolean('mcq_management')->default(false)->after('results');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_accesses', function (Blueprint $table) {
            $table->dropColumn(['practice', 'exams', 'results', 'mcq_management']);
        });
    }
};
