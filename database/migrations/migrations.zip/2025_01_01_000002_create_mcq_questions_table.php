<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mcq_questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mcq_set_id')->constrained()->cascadeOnDelete();
            $table->text('question');
            $table->string('ans_1', 500);
            $table->string('ans_2', 500);
            $table->string('ans_3', 500);
            $table->string('ans_4', 500);
            $table->enum('correct_ans', ['1', '2', '3', '4'])->comment('1=ans_1, 2=ans_2, 3=ans_3, 4=ans_4');
            $table->text('notes')->nullable()->comment('Explanation or additional notes');
            $table->text('report')->nullable()->comment('Report or flag issues');
            $table->integer('marks')->default(1);
            $table->timestamps();
            
            $table->index('mcq_set_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mcq_questions');
    }
};
