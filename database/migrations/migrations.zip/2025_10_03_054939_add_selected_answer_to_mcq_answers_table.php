<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('mcq_answers', function (Blueprint $table) {
            // Add selected_answer column if it doesn't exist
            if (!Schema::hasColumn('mcq_answers', 'selected_answer')) {
                $table->string('selected_answer')->nullable()->after('mcq_set_id');
            }
            
            // Add marks_obtained column if it doesn't exist
            if (!Schema::hasColumn('mcq_answers', 'marks_obtained')) {
                $table->integer('marks_obtained')->default(0)->after('is_correct');
            }
            
            // Add time_taken column if it doesn't exist
            if (!Schema::hasColumn('mcq_answers', 'time_taken')) {
                $table->integer('time_taken')->default(0)->after('marks_obtained');
            }
        });
        
        // Copy data from selected_ans to selected_answer if selected_ans exists
        if (Schema::hasColumn('mcq_answers', 'selected_ans')) {
            DB::statement('UPDATE mcq_answers SET selected_answer = selected_ans WHERE selected_answer IS NULL');
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('mcq_answers', function (Blueprint $table) {
            if (Schema::hasColumn('mcq_answers', 'selected_answer')) {
                $table->dropColumn('selected_answer');
            }
            if (Schema::hasColumn('mcq_answers', 'marks_obtained')) {
                $table->dropColumn('marks_obtained');
            }
            if (Schema::hasColumn('mcq_answers', 'time_taken')) {
                $table->dropColumn('time_taken');
            }
        });
    }
};
