<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Support\Str;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'google_id',
        'avatar',
        'email_verified_at',
        'uid',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    /**
     * Boot the model.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($user) {
            if (empty($user->uid)) {
                $user->uid = static::generateUniqueUid();
            }
        });
    }

    /**
     * Generate a unique UID for the user.
     */
    public static function generateUniqueUid(): string
    {
        do {
            $uid = 'USR-' . Str::upper(Str::random(6));
        } while (static::where('uid', $uid)->exists());

        return $uid;
    }

    /**
     * Get the MCQ sets for the user.
     */
    public function mcqSets()
    {
        return $this->hasMany(McqSet::class);
    }

    /**
     * Get the MCQ answers for the user.
     */
    public function mcqAnswers()
    {
        return $this->hasMany(McqAnswer::class);
    }

    /**
     * Get the posts for the user.
     */
    public function posts()
    {
        return $this->hasMany(Post::class);
    }

    /**
     * Get the access permissions for the user.
     */
    public function access()
    {
        return $this->hasOne(UserAccess::class);
    }

    /**
     * Get or create access permissions for the user.
     */
    public function getOrCreateAccess()
    {
        return $this->access ?: $this->access()->create([
            'classmate' => false,
            'leaderboard' => false,
            'post' => false,
        ]);
    }

    /**
     * Check if user has access to a specific page.
     */
    public function hasPageAccess(string $page): bool
    {
        $access = $this->access;
        return $access ? $access->hasAccess($page) : false;
    }

    /**
     * Grant access to a specific page.
     */
    public function grantPageAccess(string $page): bool
    {
        $access = $this->getOrCreateAccess();
        return $access->grantAccess($page);
    }

    /**
     * Revoke access to a specific page.
     */
    public function revokePageAccess(string $page): bool
    {
        $access = $this->access;
        return $access ? $access->revokeAccess($page) : false;
    }
}
